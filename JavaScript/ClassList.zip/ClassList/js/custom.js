// function addClass(){
//     document.getElementById('answer1').classList.add('display');
// }

// function removeClass(){
//     document.getElementById('answer2').classList.remove('display');
// }

// function toggleClass(){
//     document.getElementById('answer3').classList.toggle('display');
// }


function toggleClass(i){
    document.getElementById('answer'+i).classList.toggle('display');
}
