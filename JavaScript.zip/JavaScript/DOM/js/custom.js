
// var output = document.getElementById('row3').innerText

// var output = document.getElementById('row3').innerHTML


// document.getElementById('row1').innerText = output
// console.log(output);


// var output = document.getElementById('main').innerHTML
// var output = document.getElementById('main').innerText


// var output = document.getElementsByClassName('row')
// output[2].innerText  = output[0].innerText;
// console.log(output[1].innerHTML)

// var output = document.getElementsByTagName('div')

// var output = document.querySelector('#row1').innerText;

// var output = document.querySelectorAll('div');

// output.forEach((value) => {
//     console.log(value.innerHTML);
// })

// console.log(output);


// var output =  document.getElementById('name').value

// // console.log(output);
// document.getElementById('name').value = 'Welcome to WS';


// var output = document.querySelector('img').src;
// console.log(output)
// document.querySelector('img').src = 'images/2.jpg';


// document.getElementById('row1').style.backgroundColor = 'red';
// document.getElementById('row1').style.color = 'white';


document.querySelector('img').setAttribute('src', 'images/2.jpg');